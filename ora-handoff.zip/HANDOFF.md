# Ora: handoff notes (from the chat of 10 Nov 2026)

Carrie builds the Ora PWA (https://carriebradley.github.io/Ora/) from an iPhone and uploads files through the GitHub web UI. After every upload she closes and reopens Ora twice. Bump the cache name in `sw.js` on every send.

## Standing rules

- Keep verified material separate from reconstructed material, and never invent liturgical texts.
- Church history and justice content: Catholic only (justice content may run up to the present day).
- Daily content should come in small chunks spread across many days.
- Serif font for prayer and reading text; system font for labels and notes.
- Take the initiative; she usually replies "Ok".

## What is in this zip

- `catholic-hours/`: the full app source.
  - The live site has everything up to cache **ora-v95**.
  - This copy also has unsent changes in `app.js` and `sw.js`:
    - a loader for `oortext.json` and a "Read it here" link under the Office of Readings second reading (shown only when the entry has `t:1`);
    - `sw.js` now caches `oortext.json` after first use, like `matins.json`.
  - These changes still need finishing, a test, and a bump to ora-v96 before sending.
- `work/oor/`: the Office of Readings tables and `build.py`, which writes `catholic-hours/oor.js`. Sources:
  - `bib_*.txt`: Scripture readings.
  - `nb_*.txt`: the second reading (author and work).
  - `nb_saints.txt` and `bib_saints.txt`: the saints' days.
  - All come from Felix Just's index at catholic-resources.org/LoH.
- `work/pf/`: the full texts of the early Fathers, made from the user's PDFs.
  - **PDFs** (attach them again if needed):
    - Lake, *Apostolic Fathers* vol. 1 (archive.org `apostolicfathers01lake`);
    - Lake, vol. 2 (archive.org `apostolicfathers02lakeuoft`);
    - *Ante-Nicene Fathers* vol. 1 (archive.org `cuaantenicenefat01robe`).
  - **OCR output**: `ocr_l1/`, `ocr_l2/`, `ocr_anf/`.
  - **Main scripts**:
    - `extract.py` builds `extract_all.json`, one entry per reading;
    - `fixes.py` holds the OCR corrections;
    - `want.py` maps each Office of Readings row to its source;
    - `assemble.py` and `anfp.py` are the parsers.

## Status of the Fathers' texts (64 readings)

**Lake, 48 readings** (1 & 2 Clement, Ignatius, Polycarp, Didache, Barnabas, Diognetus, Martyrdom of Polycarp): proofread, with corrections in `fixes.py`.

Two items still need finishing:

1. **Martyrdom of Polycarp 13:3–15:2.** The OCR is garbled. Transcribe it from Lake vol. 2, pages 341 and 343 of the PDF, and use that transcription to replace the entry in `extract_all.json`. Section 13:2 is fine up to "even before his martyrdom".
2. **2 Clement 12:1.** The page OCR failed. The correct sentence is in `fixes.OVERRIDE` but is not yet used in `extract.py`.

**Irenaeus (14 readings) and Justin (2), ANF vol. 1:** extracted but not yet proofread. Problems to watch for:

- footnote debris;
- Latin and Greek fragments;
- marginal Scripture references (for example "John xv. 3S.");
- "Lorp" for "Lord".

## Remaining steps

1. Finish the two items above, then proofread Irenaeus and Justin. Use the review list from `python3 rev.py extract_all.json`, and keep long passages out of the chat.
2. Write `catholic-hours/oortext.json` in the form `{"Author|Work": {"p": [paragraphs], "src": "Tr. Kirsopp Lake, The Apostolic Fathers (1912)"}}`.
   - The key must match the `a + '|' + w` strings in `oor.js`.
   - Escape the HTML.
   - Drop the `[c:v]` verse labels, or render them as `<sup>`.
   - Credit ANF texts as "Tr. A. Roberts & J. Donaldson, Ante-Nicene Fathers vol. 1 (1885)".
3. Re-run `work/oor/build.py` with `t:1` set on every entry that has a text, then add both translations to the More → Credits text.
4. Test with Playwright, bump `sw.js` to ora-v96, and send `app.js`, `sw.js`, `oor.js` and `oortext.json`.
5. Later, if wanted: Leo the Great and Augustine from NPNF.

Other offers still open: a Dominican or Benedictine office option, and the three days with no Sarum Mass.
