import re,json,glob
D={'Sunday':0,'Monday':1,'Tuesday':2,'Wednesday':3,'Thursday':4,'Friday':5,'Saturday':6}
def key(l):
    l=l.strip()
    m=re.match(r'(\d+)\w\w Sunday (?:of|in) (Advent|Lent|Easter|Ord\. Time)',l)
    S={'Advent':'a','Lent':'l','Easter':'e','Ord. Time':'o'}
    if m: return f"{S[m[2]]}{m[1]}-0"
    m=re.match(r'(\d+)\w\w Week (?:of|in) (Advent|Lent|Easter|Ord\. Time)[,:] (\w+)',l)
    if m: return f"{S[m[2]]}{m[1]}-{D[m[3]]}"
    m=re.match(r'Dec\. (\d+)$',l)
    if m: return f"d{m[1]}"
    m=re.match(r'From Jan\. 2 to Epiphany: (\w+)',l)
    if m: return f"j-{D[m[1]]}"
    m=re.match(r'After Epiphany to the Baptism of the Lord: (\w+)',l)
    if m: return f"pe-{D[m[1]]}"
    m=re.match(r'(\w+) after Ash Wednesday',l)
    if m: return f"ash-{D[m[1]]}"
    m=re.match(r'Holy Week, (\w+)',l)
    if m: return f"hw-{D[m[1]]}"
    m=re.match(r'(\w+) within the Octave of Easter',l)
    if m: return 'e2-0' if m[1]=='Sunday' else f"e1-{D[m[1]]}"
    fixed={'Ash Wednesday':'ash-3','Passion Sunday (Palm Sunday)':'palm','Holy Thursday':'hw-4','Good Friday':'hw-5','Holy Saturday':'hw-6',
      'Easter Sunday':'e1-0','Ascension':'asc','Pentecost':'pent','Trinity Sunday':'trin','Corpus Christi':'corp','Sacred Heart':'sh',
      'Christ the King':'o34-0','Dec. 25: Christmas':'xmas','Sunday in the Octave of Christmas: Holy Family':'hf',
      'Jan. 1: Octave of Christmas: Mary, Mother of God':'jan1','Jan. 6 or Sunday between Jan. 2-8: Epiphany':'epi','Sun. after Jan. 6: Baptism of the Lord':'bap'}
    if l in fixed: return fixed[l]
    raise Exception('?? '+l)
BK={'Chron':'chronicles','Cor':'corinthians','John':'john','Kings':'kings','Mac':'maccabees','Pet':'peter','Sam':'samuel','Thess':'thessalonians','Tim':'timothy',
'Acts':'acts','Amos':'amos','Bar':'baruch','Col':'colossians','Dan':'daniel','Deut':'deuteronomy','Eccl':'ecclesiastes','Eph':'ephesians','Est':'esther','Exod':'exodus',
'Ezek':'ezekiel','Gal':'galatians','Gen':'genesis','Hab':'habakkuk','Hag':'haggai','Heb':'hebrews','Hos':'hosea','Isa':'isaiah','Jer':'jeremiah','Job':'job','Joel':'joel',
'Josh':'joshua','Jude':'jude','Judg':'judges','Lam':'lamentations','Lev':'leviticus','Mal':'malachi','Mic':'micah','Num':'numbers','Phil':'philippians','Prov':'proverbs',
'Rev':'revelation','Rom':'romans','Sir':'sirach','Song':'song of solomon','Wis':'wisdom','Zech':'zechariah','Zeph':'zephaniah'}
def api(r):
    m=re.match(r'((?:\d )?)([A-Za-z]+)\.? (.*)$',r)
    book=(m[1]+BK[m[2]]); rest=m[3]; out=[]; ch=None
    for seg in re.split(r'[;,]',rest):
        seg=re.sub(r'(\d)[abc]\b',r'\1',seg.strip())
        if not seg: continue
        if ':' in seg.split('-')[0]:
            c,v=seg.split(':',1); ch=c
            out.append(f"{book} {c}:{v}")
            if '-' in v and ':' in v.split('-')[1]: ch=v.split('-')[1].split(':')[0]
        else: out.append(f"{book} {ch}:{seg}")
    return '|'.join(out)
def ref(r): return r.strip().replace('—','-')
O={}
for f in glob.glob('bib_*.txt'):
    if 'saints' in f: continue
    for line in open(f):
        if '|' not in line: continue
        a,b=line.split('|',1); O.setdefault(key(a),{})['r']=ref(b); O[key(a)]['q']=api(ref(b))
for f in glob.glob('nb_*.txt'):
    if 'saints' in f: continue
    for line in open(f):
        if '|' not in line: continue
        a,b,c=[x.strip() for x in line.split('|',2)]
        b=b.replace('Bernard, abbot','Bernard of Clairvaux')
        O.setdefault(key(a),{})['a']=b; O[key(a)]['w']=c.replace('—','–')
SA={}
for line in open('nb_saints.txt'):
    md,rest=line.split(' ',1); n,a,w=[x.strip() for x in rest.split('|')]
    SA.setdefault(md,[]).append({'n':n,'a':a,'w':w})
for line in open('bib_saints.txt'):
    md,r=[x.strip() for x in line.split('|')]; SA[md][0]['r']=ref(r); SA[md][0]['q']=api(ref(r))
miss=[k for k,v in O.items() if 'r' not in v or 'a' not in v]
print(len(O),'season keys; incomplete:',miss); print(len(SA),'saint days')
open('/home/claude/catholic-hours/oor.js','w').write('self.OOR='+json.dumps(O,ensure_ascii=False,separators=(',',':'))+';\nself.OOR_SAINTS='+json.dumps(SA,ensure_ascii=False,separators=(',',':'))+';\n')
