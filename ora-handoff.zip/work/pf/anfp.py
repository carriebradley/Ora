import re,statistics,os
from tsvp import page_lines
from merge import inv
def rom(t):
    t=t.replace('l','I').replace('1','I').replace(']','I').replace('|','I')
    vals={'I':1,'V':5,'X':10,'L':50,'C':100}
    if not t or any(ch not in vals for ch in t): return None
    n=0
    for k,ch in enumerate(t):
        v=vals[ch]; nx=vals[t[k+1]] if k+1<len(t) else 0
        n+= -v if v<nx else v
    return n
def col_lines(path):
    ls=page_lines(path)
    if not ls: return []
    hmed=statistics.median([l['h'] for l in ls if len(l['ws'])>=5] or [40])
    out=[]
    cut=len(ls)
    for i,l in enumerate(ls):
        tx=' '.join(w['x'] for w in l['ws'])
        if i>len(ls)*0.4 and l['h']<hmed*0.88 and 'CHAP' not in tx and not re.fullmatch(r"[A-Z0-9 ,.;:’'—\-()?!“”\"&]+",tx):
            cut=i; break
    ls=ls[:cut]
    for i,l in enumerate(ls):
        txt=' '.join(w['x'] for w in l['ws'] if w['x'] not in ('|','||'))
        txt=re.sub(r'^[|\\.,:;]+\s*','',txt)
        if i==0 and re.search(r'[A-Z]{4,}|^\d+$',txt) and len(l['ws'])<=6: continue
        if l['h']<hmed*0.84 and 'CHAP' not in txt: continue
        if re.fullmatch(r'[\W\d_]*',txt): continue
        out.append(txt)
    return out
def stream(pages):
    L=[]
    for p in pages:
        for s in 'LR':
            f=f'ocr_anf/{p}_{s}.tsv'
            if os.path.exists(f): L+=[(p,x) for x in col_lines(f)]
    return L
def parse(pages, justin=False):
    L=stream(pages); C={}; c=None; sec=None; cur=[]; inhead=False
    def flush():
        if c is not None and sec is not None: C.setdefault(c,{})[sec]=' '.join(cur)
    for p,t in L:
        m=re.match(r'^[_\W]*CHAP[.,]?\s*([IVXLC1l\]|]+)[.,]?',t)
        if m:
            flush(); r=rom(m.group(1)); c = r if (r and (c is None or c<r<=c+3)) else (c+1 if c else r); sec=1; cur=[]; inhead=True; continue
        if inhead:
            if re.fullmatch(r"[A-Z0-9 ,.;:’'—\-()?!“”\"&]+",t) and sum(ch.isupper() for ch in t)>len(t)*0.4: continue
            inhead=False
        m=re.match(r'^[_\W]*(\d{1,2})[.,\-]\s+(.*)',t)
        if m and c is not None:
            n=int(m.group(1))
            if n==1 and cur==[]: t=m.group(2)
            elif n in (sec+1,sec+2): flush(); sec=n; cur=[]; t=m.group(2)
        if cur and cur[-1].endswith('-'):
            cur[-1]=cur[-1][:-1]+t.lstrip('-'); t=None
        if t is not None: cur.append(t.lstrip('-'))
        # a section number in mid-line: "... truth. 5. Again ..." or "... fault. 5./ Again"
        if c is not None and sec is not None:
            joined=' '.join(cur)
            m=re.search(r'([.?!”’;:\]])\s+(%d)[.,/\-]*\s+(?=[A-Z“‘\[])' % (sec+1), joined)
            if m and len(joined[:m.start()].split())>8:
                before=joined[:m.end(1)]; after=joined[m.end():]
                cur=[before]; flush(); sec+=1; cur=[after]
    flush(); return C
if __name__=='__main__':
    import sys
    pg=list(range(int(sys.argv[1]),int(sys.argv[2])+1))
    C=parse(pg)
    print({c:sorted(s) for c,s in C.items()})
