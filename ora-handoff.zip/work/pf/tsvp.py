import csv,statistics,re,sys
def page_lines(path):
    rows=[r for r in csv.DictReader(open(path),delimiter='\t',quoting=csv.QUOTE_NONE) if r['level']=='5' and r['text'].strip()]
    L={}
    for r in rows:
        k=(int(r['block_num']),int(r['par_num']),int(r['line_num']))
        L.setdefault(k,[]).append(dict(l=int(r['left'])-100,t=int(r['top'])-100,w=int(r['width']),h=int(r['height']),x=r['text'],c=float(r['conf'])))
    lines=[]
    for k,ws in L.items():
        ws.sort(key=lambda w:w['l'])
        lines.append(dict(ws=ws,top=min(w['t'] for w in ws),left=ws[0]['l'],right=max(w['l']+w['w'] for w in ws),h=statistics.median([w['h'] for w in ws if re.search('[a-z]',w['x'])] or [w['h'] for w in ws])))
    lines.sort(key=lambda l:l['top'])
    return lines
def clean_page(path):
    lines=page_lines(path)
    if not lines: return []
    long=[l for l in lines if len(l['ws'])>=6]
    if not long: return []
    hmed=statistics.median([l['h'] for l in long])
    # body right edge: the 70th percentile of rights of long lines
    rights=sorted(l['right'] for l in long); R=rights[int(len(rights)*0.6)]
    lefts=sorted(l['left'] for l in long); Lft=lefts[int(len(lefts)*0.3)]
    out=[]; started=False; prev_top=None
    for i,l in enumerate(lines):
        ws=[w for w in l['ws'] if w['l']<R+15 and w['l']+w['w']>Lft-40]
        if not ws: continue
        txt=' '.join(w['x'] for w in ws)
        if i<=1 and (re.search(r'[A-Z]{3,}',txt) and len(ws)<=8): continue   # running head
        if re.fullmatch(r'[\divxlcIVXLC.\s]{1,6}',txt) and l['top']>2000: continue  # page number
        smallh=statistics.median([w['h'] for w in ws if re.search('[a-z]',w['x'])] or [l['h']])
        gap=l['top']-prev_top if prev_top else 0
        if started and (smallh<hmed*0.92 or gap>hmed*2.2) and (re.match(r"^[\d*†‡§'’!]",txt) and not re.match(r'^\d+\. [A-Z“‘"]',txt) or smallh<hmed*0.9 and gap>hmed*2.2): break  # footnotes
        prev_top=l['top']
        started=True
        out.append(txt)
    return out
if __name__=='__main__':
    print('\n'.join(clean_page(sys.argv[1])))
