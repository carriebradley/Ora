import re
def parse(spec):
    spec=spec.replace('–','—').replace(':',', ').replace(' ,',',')
    out=[]
    for seg in [s.strip() for s in spec.split(';') if s.strip()]:
        if '—' in seg:
            a,b=[x.strip() for x in seg.split('—')]
            pre=[]
            if ',' in a:
                ca,vs=a.split(','); ca=int(ca); vs=[int(x) for x in vs.strip().split('.') if x]
                pre=[((ca,x),(ca,x)) for x in vs[:-1]]; va=vs[-1]
            else: ca=int(a); va=1
            post=[]
            if ',' in b:
                cb,ws=b.split(','); cb=int(cb); ws=[int(x) for x in ws.strip().split('.') if x]
                vb=ws[0]; post=[((cb,x),(cb,x)) for x in ws[1:]]
            else: cb=int(b); vb=None
            out+=pre+[((ca,va),(cb,vb))]+post
        elif ',' in seg:
            c,vs=seg.split(','); c=int(c)
            for r in vs.strip().split('.'):
                if not r: continue
                if '-' in r: x,y=r.split('-'); out.append(((c,int(x)),(c,int(y))))
                else: out.append(((c,int(r)),(c,int(r))))
        elif '-' in seg:
            x,y=seg.split('-'); out.append(((int(x),1),(int(y),None)))
        else: out.append(((int(seg),1),(int(seg),None)))
    return out
if __name__=='__main__':
    for s in ['7:4—8:3; 8:5—9:1; 13:1-4; 19:2','59, 2—60, 4; 61, 3','13—18, 1','35-38','10, 1-15','12, 1—14','19, 1-3.5-7.8-12','5-6','4, 1-2; 6, 1–8, 3','36, 1-2; 37—38']: print(s,parse(s))
