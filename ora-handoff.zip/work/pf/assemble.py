import json,re,os,sys
from merge import page,inv,norm
A='/mnt/user-data/attachments/44eb94a6-bb2f-5dd7-85cd-8f519ea68ecd/'
VOLS={'l1':A+'c09c8622-apostolicfathers01lake.pdf','l2':A+'65cebd34-apostolicfathers02lakeuoft.pdf'}
def work_of(vol,p,head):
    h=head.upper()
    if vol=='l1':
        for k,w in [('EPHESIANS','eph'),('MAGNESIANS','mag'),('TRALLIANS','tral'),('ROMANS','rom'),('PHILADELPHIANS','phld'),('SMYRNAEANS','smyr'),('PHILIPPIANS','phil'),('DIDACHE','did'),('BARNABAS','barn')]:
            if k in h: return w
        if 'IGNATIUS' in h and 'POLYCARP' in h: return 'ipol'
        if 'CLEMENT' in h or h.startswith('THE'):
            return '1clem' if p<145 else '2clem' if p<185 else None
    else:
        if 'MARTYRDOM' in h: return 'mpol'
        if 'DIOGNETUS' in h or 'DIOGNESS' in h: return 'diog'
    return None
def stream(vol):
    P=json.load(open(vol+'_pages.json'))
    eng=set(int(x) for x in open('p'+vol).read().split(','))
    seq=[]
    for p in sorted(eng):
        if p-1 in eng and (vol,p)!=('l1',317): continue          # introduction pages (no facing Greek)
        if (vol,p) in {('l1',145),('l1',300),('l1',357),('l2',358)}: continue
        head=next((l.strip() for l in P[p-1].split('\n') if len(l.strip())>5),'')
        seq.append([p,work_of(vol,p,head)])
    for k in range(len(seq)-1):           # a title page takes the work of the page after it
        if seq[k][1] is None and seq[k+1][1]: seq[k][1]=seq[k+1][1]
    words={}
    for p,w in seq:
        f=f'ocr_{vol}/{p:03d}.tsv'
        if not w or not os.path.exists(f): continue
        ws,_=page(f,VOLS[vol],p)
        k=next((i for i,x in enumerate(ws) if x['x']=='§WK§'),None)
        if k is not None:
            prevw=next((x for x in reversed(list(words.keys())) ),None)
            if k>0 and prevw and prevw!=w: words.setdefault(prevw,[]).append((p,ws[:k]))
            ws=ws[k+1:]
        words.setdefault(w,[]).append((p,ws))
    return words
def clean_tokens(ws):
    toks=[]
    for k,w in enumerate(ws):
        x=w['x']
        if x=='§CH§': toks.append(x); continue
        if toks and toks[-1].endswith('-') and w.get('nl'):
            j=toks[-1][:-1]+x
            toks[-1]=j if (inv(j) or not inv(x)) else toks[-1]+x; continue
        toks.append(x)
    return toks
LOG=[]; VOL='l1'; USEHEAD=False
ROM={'I':1,'V':5,'X':10,'L':50}
VN=r'(\d{1,2}|[lI|\]]|-t|t)[.,]'
def vnum(t):
    m=re.fullmatch(VN,t)
    if not m: return None
    g=m.group(1); return 1 if g in 'lI|]' else 4 if g in ('-t','t') else int(g)
from heads import rom
CURW=None
def chapters(pages):
    from heads import head_range
    C={}; c=0; v=0; cur=[]
    P=json.load(open(VOL+'_pages.json'))
    toks=[]
    for p,ws in pages:
        toks.append(('PG',head_range(f'ocr_{VOL}/{p:03d}.tsv',P[p-1].strip().split('\n')[0]),p))
        for k,w in enumerate(ws):
            if w['x']=='§CH§': toks.append(('CH',w.get('roman','')))
            else: toks.append(w)
    # manual chapter starts the OCR missed: (first word, second word) of the chapter's first verse
    SPL={('l1','phil'):[('Sranp','fast')],('l2','mpol'):[('So','they','did')]}.get((VOL,CURW),[])
    if SPL:
        t2=[]
        for k,t in enumerate(toks):
            if isinstance(t,dict):
                for a in SPL:
                    nxt=[x['x'] for x in toks[k:k+len(a)] if isinstance(x,dict)]
                    if tuple(nxt)==a and k>0 and isinstance(toks[k-1],dict) and re.fullmatch(r'[1lL|I]\.?|\d\.',toks[k-1]['x']):
                        t2.pop(); t2.append(('CH','')); t2.append(dict(x='1.'))
            t2.append(t)
        toks=t2
    # dehyphenate plain words
    flat=[]
    for t in toks:
        if isinstance(t,dict):
            x=t['x']
            if flat and isinstance(flat[-1],str) and flat[-1].endswith('-') and t.get('nl'):
                j=flat[-1][:-1]+x; flat[-1]=j if (inv(j) or not inv(x)) else flat[-1]+x; continue
            flat.append(x)
        else: flat.append(t)
    def flush():
        if c and v: C.setdefault(c,{})[v]=' '.join(cur)
    i=0; pagerange=None
    while i<len(flat):
        t=flat[i]
        if isinstance(t,tuple) and t[0]=='PG':
            rng=[(a,b) for (a,va),(b,vb) in t[1] if a and b and a<=b]
            pagerange=rng[0] if rng else None
            starts=[a for (a,va),_ in t[1] if a]
            if False:
                a=starts[0]; va=[va for (x,va),_ in t[1] if x==a][0]
                flush(); c,v=a,va; cur=[]
            i+=1; continue
        if isinstance(t,tuple) and t[0]=='CH':
            if c and v==1 and not cur and c not in C:   # duplicate marker for the same chapter
                i+=1
                if i<len(flat) and isinstance(flat[i],str) and vnum(flat[i])==1: i+=1
                continue
            val=rom(t[1]) if t[1] else None
            ok = val and c<val<=c+3
            flush(); c = val if ok else c+1; v=1; cur=[]; i+=1
            if i<len(flat) and isinstance(flat[i],str) and vnum(flat[i])==1: i+=1
            continue
        n=vnum(t)
        if n==1 and c==0: c=1; v=1; cur=[]; i+=1; continue
        if n is not None and v and n in (v+1,v+2) and not (n==v+2 and len(cur)<3):
            flush(); v=n; cur=[]; i+=1; continue
        if n==1 and cur:
            prev=cur[-1]; nxt=flat[i+1] if i+1<len(flat) and isinstance(flat[i+1],str) else ''
            romprev=re.fullmatch(r'[IVXLC][IVXLCl1|ivx]{0,6}\.?',prev) is not None and prev not in ('I','I.')
            if romprev or (v>=2 and re.search(r'[.?!”’]$',prev) and re.match(r'[A-Z“‘]',nxt)):
                if romprev: cur.pop()
                flush(); c+=1; v=1; cur=[]; i+=1; continue
        cur.append(t); i+=1
    flush()
    return C
if __name__=='__main__':
    VOL=sys.argv[1]; S=stream(sys.argv[1])
    for w,pages in S.items():
        C=chapters(pages)
        print(w,len(pages),'pages',len(C),'chapters',{c:len(v) for c,v in list(C.items())[:70]})
