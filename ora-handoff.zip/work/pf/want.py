import re
ROWS=[]
for f in ['nb_advent.txt','nb_lent_easter.txt','nb_ot1.txt','nb_ot2.txt']:
    for line in open('/home/claude/work/oor/'+f):
        if line.count('|')<2: continue
        _,a,w=[x.strip() for x in line.split('|',2)]
        ROWS.append((a.replace('Bernard, abbot','Bernard of Clairvaux'),w.replace('—','–')))
for line in open('/home/claude/work/oor/nb_saints.txt'):
    md,rest=line.split(' ',1); n,a,w=[x.strip() for x in rest.split('|')]
    ROWS.append((a,w))
def target(a,w):
    W=w
    if a=='Clement of Rome': return ('l1','1clem',re.sub(r'^Letter to the Corinthians\s*','',W))
    if a=='A second-century author': return ('l1','2clem',re.sub(r'^.*Clement\)\s*','',W))
    if a=='Ignatius of Antioch':
        for k,v in [('Ephesians','eph'),('Magnesians','mag'),('Trallians','tral'),('Romans','rom'),('Philadelphians','phld'),('Smyrnaeans','smyr'),('Polycarp','ipol')]:
            if k in W: return ('l1',v,re.sub(r'^.*?'+k+r'\s*','',W))
    if a=='Polycarp of Smyrna': return ('l1','phil',re.sub(r'^To the Philippians\s*','',W))
    if a=='The Didache': return ('l1','did',W)
    if W.endswith('10, 1-15'): W=W.replace('10, 1-15','10, 1–15')
    if a=='Letter of Barnabas': return ('l1','barn',W)
    if a=='Letter to Diognetus': return ('l2','diog',W)
    if a=='Church of Smyrna': return ('l2','mpol','13, 2—14')   # Lake's ch. 14 here holds 14-15 (OCR merged the chapter break)
    if a=='Irenaeus of Lyons' and W.startswith('Against Heresies'): return ('anf','iren',W.replace('Against Heresies','').strip())
    if a=='Justin Martyr' and 'First Apology' in W: return ('anf','apol',W.replace('First Apology','').strip())
    return None
WANT={}
for a,w in ROWS:
    t=target(a,w)
    if t: WANT[a+'|'+w]=t
if __name__=='__main__':
    for k,v in WANT.items(): print(v, '<=', k)
    print(len(WANT))
