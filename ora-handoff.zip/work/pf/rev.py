import json,re,sys
from merge import inv
def ok(core):
    if inv(core): return True
    parts=[p for p in re.split(r'[-’\']',core) if p]
    if len(parts)>1 and all(inv(p) for p in parts): return True
    c=core.lower()
    for a,b in [('our','or'),('ise','ize'),('ised','ized'),('ising','izing'),('re','er'),('ll','l'),('ce','se'),('ph','f'),('oe','e'),('ae','e')]:
        if a in c and inv(c.replace(a,b)): return True
    if c.endswith('eth') and (inv(c[:-3]) or inv(c[:-3]+'e')): return True
    if c.endswith('est') and (inv(c[:-3]) or inv(c[:-2])): return True
    if c.endswith(('ed','es','s')) and inv(re.sub(r'(ed|es|s)$','',c)): return True
    return False
def flags(txt):
    toks=txt.split(' '); F=[]
    for i,t in enumerate(toks):
        if re.fullmatch(r'\[\d+:\d+\]',t): continue
        core=re.sub(r"[^A-Za-z’'\-]","",t).strip("-’'")
        bad=(core and not ok(core) and not (core[0].isupper() and core[1:].islower() and len(core)>2)) or re.search(r"[|{}\\~^_<>»«¢&®©]|\w[?!;:]\w|[A-Za-z]\d|\d[A-Za-z]",t)
        if core and core[0].isupper() and len(core)>2 and core[1:].islower() and not ok(core) and core.lower() not in ('esaias','zacchaeus'):
            # capitalised unknowns: flag only if they look like OCR of small caps (e.g. Tuere, Ler, Anp)
            if re.fullmatch(r'(T[un][a-z]*|L[e]r|An[pn]|Bur|Wu[a-z]*|Ir|Iv|Kno[a-z]*|See[a-z]*|Fo[a-z]*cu|Sr[a-z]*|Br[a-z]*)',core): bad=True
        if bad: F.append((t,' '.join(toks[max(0,i-3):i+4])))
    return F
if __name__=='__main__':
    R=json.load(open(sys.argv[1]))
    n=0
    for k,v in R.items():
        F=flags(' '.join(v['p'] or []))
        print(f'## {k} | {v["probs"]}'); n+=len(F)
        for a,b in F: print(f'   [{a}]  {b}')
    print('TOTAL',n)
