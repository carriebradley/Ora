import assemble,json,re,sys
from heads import head_range
def flat(vol,w):
    assemble.VOL=vol; S=assemble.stream(vol)
    P=json.load(open(vol+'_pages.json'))
    out=[]
    for p,ws in S[w]:
        hr=head_range(f'ocr_{vol}/{p:03d}.tsv',P[p-1].strip().split('\n')[0])
        out.append(('PG',p,hr))
        for x in ws: out.append(x['x'] if x['x']!='§CH§' else ('CH',x.get('roman','')))
    return out
if __name__=='__main__':
    vol,w=sys.argv[1],sys.argv[2]
    F=flat(vol,w)
    for i,t in enumerate(F):
        if isinstance(t,tuple) and t[0]=='PG': print('--- page',t[1],t[2])
        elif isinstance(t,tuple): print(i,'CH',t[1],' '.join(x for x in F[i+1:i+9] if isinstance(x,str)))
        elif re.fullmatch(r'(1|l|I)[.,]',t): print(i,'1.',' '.join(x for x in F[i+1:i+9] if isinstance(x,str)))
