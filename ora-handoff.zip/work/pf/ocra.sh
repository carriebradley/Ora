for p in $(seq 341 345) $(seq 455 464) $(seq 478 482) $(seq 488 504) $(seq 537 541) $(seq 558 562) $(seq 192 201); do
  f=ocr_anf/$p; [ -f $f.txt ] && continue
  pdftoppm -f $p -l $p -r 300 -gray -png -singlefile /mnt/user-data/uploads/cuaantenicenefat01robe.pdf /tmp/anfpg
  tesseract /tmp/anfpg.png $f -l eng --psm 3 >/dev/null 2>&1
done
echo anfdone
