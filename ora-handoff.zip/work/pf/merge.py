import re,subprocess,statistics,difflib,json,os,html
from tsvp import page_lines
S=300/72
DEBUG=False
def load_vocab():
    V=set()
    for l in open('/usr/share/hunspell/en_US.dic',encoding='latin-1').read().split('\n')[1:]:
        w,_,fl=l.partition('/'); w=w.lower()
        if not w: continue
        V.add(w)
        for suf in ['s','es','ed','d','ing','ly','er','ers','est','ness','eth','est',"'s"]:
            V.add(w+suf)
        if w.endswith('e'): V.update([w[:-1]+'ing',w[:-1]+'eth',w+'st',w+'th'])
        if w.endswith('y'): V.update([w[:-1]+'ies',w[:-1]+'ied',w[:-1]+'ieth',w[:-1]+'ily'])
    V.update('thee thou thy thine ye hath doth saith shalt wilt art hast didst canst wouldst shouldst unto o amen beloved christ jesus god lord israel'.split())
    return V
VOC=load_vocab()
def _freq():
    import collections,json
    c=collections.Counter()
    for n in ['l1','l2']:
        for p in json.load(open(f'/home/claude/work/pf/{n}_pages.json')): c.update(re.findall(r"[a-z]+",p.lower()))
    return {w for w,k in c.items() if k>=4 and len(w)>1}
VOC|=_freq()
VOC|={w.replace('or','our') for w in list(VOC) if w.endswith('or') or w.endswith('ors')}
def norm(w): return re.sub(r"[^a-z0-9']","",w.lower().replace('’',"'"))
def inv(w):
    if re.fullmatch(r'[-—_|~=]+',w): return False
    if re.fullmatch(r'\d{1,2}\.',w): return True
    n=norm(w).strip("'")
    if re.search(r'\d',n): return False
    return (not n) or n in VOC or n.endswith("'s") and n[:-2] in VOC
def pdf_words(pdf,page):
    t=subprocess.run(['pdftotext','-f',str(page),'-l',str(page),'-bbox',pdf,'-'],capture_output=True,text=True).stdout
    return [dict(l=float(a)*S,t=float(b)*S,r=float(c)*S,b=float(d)*S,x=html.unescape(x)) for a,b,c,d,x in re.findall(r'xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)<',t)]
def page(tsv,pdf,pno):
    lines=page_lines(tsv)
    long=[l for l in lines if len(l['ws'])>=6]
    if not long: return [],{}
    hmed=statistics.median([l['h'] for l in long])
    from collections import Counter
    # justified body lines end at the same x; margin-note lines end further right
    ends=[]
    for l in long:
        for w in l['ws']: ends.append(round((w['l']+w['w'])/12))
    cnt=Counter(e for e in ends if e*12>700); R=max(cnt.items(),key=lambda kv:kv[1])[0]*12+6
    lefts=sorted(l['left'] for l in long); Lft=lefts[int(len(lefts)*0.3)]
    T=[]; started=False; prev=None; top=None; bottom=99999
    for i,l in enumerate(lines):
        ws=[w for w in l['ws'] if w['l']<R and w['l']+w['w']>Lft-40]
        if not ws: continue
        txt=' '.join(w['x'] for w in ws)
        mt=re.search(r'IGNATIUS\s+TO\s+(THE\s+)?([A-Z]{5,})|POLYCARP\s+TO\s+THE\s+PHILIPPIANS|EPISTLE\s+TO\s+THE\s+PHILIPPIANS',txt)
        if i>0 and mt and re.search(r'[—-]|EPISTLE',txt):
            T.append(dict(x='§WK§',nl=True,y=l['top'],title=txt)); continue
        core=re.sub(r'[^A-Za-z0-9|]','',txt)
        lc=(l['left']+l['right'])/2; mid=(Lft+R)/2
        if i>0 and abs(lc-mid)<160 and l['right']-l['left']<300 and re.fullmatch(r'[IVXLCl1|ivxuntm]{1,8}',core) and re.match(r'[IVXL]',core):
            T.append(dict(x='§CH§',nl=True,y=l['top'],roman=core)); prev=l['top']; started=True
            if top is None: top=l['top']-10
            continue
        if (i==0 or i==1 and len(ws)>2) and re.search(r'[A-Z]{3,}',txt) and len(ws)<=8 and not re.fullmatch(r'[IVXLC]+',txt): continue
        if re.fullmatch(r'[\divxlcIVXLC.\s]{1,6}',txt) and l['top']>2000: continue
        sh=statistics.median([w['h'] for w in ws if re.search('[a-z]',w['x'])] or [l['h']])
        gap=l['top']-prev if prev else 0
        prevsolo = bool(T) and T[-1]['x']=='§CH§'
        nalpha=sum(1 for w in ws if re.search(r'[A-Za-z]{2,}',w['x']))
        if sh<hmed*0.6: continue   # speckle lines
        if nalpha<2 and not re.match(r'^\d+[.,]',txt) and not any(re.search(r'[a-z]{3,}',w['x']) for w in ws): continue   # stray marks / margin debris
        if started and not prevsolo and ((sh<hmed*0.92 or gap>hmed*2.2) and re.match(r"^[\d*†‡§'’!]",txt) and not re.match(r'^\d+[.,] ?[A-Z“‘"]',txt) or sh<hmed*0.9 and (gap>hmed*1.9 or l['left']>Lft+40)):
            bottom=l["top"]-5
            if DEBUG: print("BREAK",i,l["top"],sh,hmed,gap,txt[:40])
            break
        prev=l['top']; started=True
        if top is None: top=l['top']-10
        for j,w in enumerate(ws): T.append(dict(x=w['x'],nl=(j==0),y=l['top']))
    if top is None: return [],{}
    A=[] if 'lakeuoft' in pdf else [w for w in pdf_words(pdf,pno) if w['t']>=top-10 and w['t']<bottom and w['l']<R and w['r']>Lft-40]
    A.sort(key=lambda w:(round(w['t']/20),w['l']))
    a=[norm(w['x']) for w in A]; t=[norm(w['x']) for w in T]
    out=[]; stats={'rep':0,'ins':0}
    for op,i1,i2,j1,j2 in difflib.SequenceMatcher(None,t,a,autojunk=False).get_opcodes():
        if op=='equal': out+=T[i1:i2]
        elif op=='replace' and i2-i1==j2-j1:
            for k in range(i2-i1):
                tw,aw=T[i1+k],A[j1+k]
                if not inv(tw['x']) and inv(aw['x']) and norm(aw['x']): out.append(dict(tw,x=aw['x'],fix=1)); stats['rep']+=1
                else: out.append(tw)
        elif op=='replace':
            tv=sum(inv(w['x']) for w in T[i1:i2])/(i2-i1); av=sum(inv(w['x']) for w in A[j1:j2])/(j2-j1)
            if av>tv and av==1: out+=[dict(x=w['x'],nl=(k==0 and T[i1]['nl']),fix=1) for k,w in enumerate(A[j1:j2])]; stats['rep']+=1
            else: out+=T[i1:i2]
        elif op=='insert':
            ws=A[j1:j2]
            endline = i1>=len(T) or T[i1]['nl']
            if endline and i1<len(T) and i1>0: endline = not ws[0]['l'] < 200
            if all(inv(w['x']) and norm(w['x']) for w in ws) and len(ws)<=3 and not (endline and ws[0]['l']>600): out+=[dict(x=w['x'],nl=(k==0 and ws[0]['l']<200 and endline),fix=1) for k,w in enumerate(ws)]; stats['ins']+=1
        elif op=='delete':
            out+=[w for w in T[i1:i2] if w['x'] not in ('-','—','_','|')]
    return out,stats
def to_lines(ws):
    L=[]
    for w in ws:
        if w.get('nl') or not L: L.append([])
        L[-1].append(w['x'])
    return [' '.join(l) for l in L]
if __name__=='__main__':
    import sys
    ws,st=page(f'ocr_l1/{int(sys.argv[1]):03d}.tsv','/mnt/user-data/attachments/44eb94a6-bb2f-5dd7-85cd-8f519ea68ecd/c09c8622-apostolicfathers01lake.pdf',int(sys.argv[1]))
    print('\n'.join(to_lines(ws))); print(st)
    print('NONVOC',[w['x'] for w in ws if not inv(w['x'])])
