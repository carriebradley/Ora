import re,json,sys
import assemble, anfp
from spec import parse
from want import WANT
from merge import inv
SMALLCAPS={'Tue':'The','Tne':'The','Tur':'The','Anp':'And','Owinc':'Owing','Owine':'Owing','Weare':'We are','Wuererore':'Wherefore','Att':'All','Wuen':'When','Bur':'But','Lrt':'Let','Ler':'Let','Ir':'It','Wuar':'What','Ture':'True','Tuts':'This','Tuis':'This','Tuerefore':'Therefore','Tuererore':'Therefore','Wuerefore':'Wherefore','Wuo':'Who','Brernren':'Brethren','Breruren':'Brethren','Breturen':'Brethren'}
def tidy(s):
    t=s.split(' ')
    out=[]
    for k,w in enumerate(t):
        nxt=t[k+1] if k+1<len(t) else ''
        if w in SMALLCAPS: w=SMALLCAPS[w]
        w={'Lorp':'Lord','Gop':'God','Lorv':'Lord','Lorn':'Lord'}.get(w,w)
        w=re.sub(r'(?<=[A-Za-z.,;:’”?)])[0-9*†°™+]+$','',w)          # superscript note numbers
        w=re.sub(r'(?<=[”’])[?!*]$','',w) if re.match(r'[A-Z]',nxt or 'A') else w
        if re.fullmatch(r'[0-9]*[°™+*†]+|\d+[°™]',w): w=''
        if re.fullmatch(r'[0-9*†]+[;,.:]?',w) and not re.fullmatch(r'\d+\.',w): w=re.sub(r'[0-9*†]','',w)
        if w.endswith('!') and re.match(r'[a-z]',nxt) and re.search(r'[,.;:’”]!$',w): w=w[:-1]
        w=w.replace('_','')
        if w: out.append(w)
    # drop runs of footnote debris: 3+ consecutive tokens that are mostly not English words
    keep=[True]*len(out)
    for k in range(len(out)):
        win=out[k:k+4]
        if len(win)==4 and sum(1 for x in win if not inv(x) and re.search('[A-Za-z]',x))>=3:
            for j in range(k,k+4): keep[j]=False
    out=[x for x,kp in zip(out,keep) if kp]
    s=' '.join(out)
    s=re.sub(r'\s+([?;:!,.])',r'\1',s); s=re.sub(r'“\s+','“',s); s=re.sub(r'\s+”','”',s); s=re.sub(r"‘\s+","‘",s)
    s=s.replace(' ’ ','’ ')
    return s.strip()
CACHE={}; SS={}
def source(vol,work):
    k=(vol,work)
    if k in CACHE: return CACHE[k]
    if vol in ('l1','l2'):
        assemble.VOL=vol; S=SS.get(vol) or SS.setdefault(vol,assemble.stream(vol)); assemble.CURW=work; C=assemble.chapters(S.get(work,[]))
    else:
        if work=='apol': C=anfp.parse(list(range(192,202)))
        else: C=None
    CACHE[k]=C; return C
IREN_PAGES={1:range(341,346),3:range(455,465),4:list(range(478,483))+list(range(488,505)),5:list(range(537,542))+list(range(558,563))}
def excerpt(vol,work,spec):
    if work=='iren':
        b,rest=spec.split(',',1); b=int(b)
        k=('anf','iren',b)
        if k not in CACHE:
            pg=list(IREN_PAGES[b]); blocks=[[pg[0]]]
            for p in pg[1:]:
                if p==blocks[-1][-1]+1: blocks[-1].append(p)
                else: blocks.append([p])
            D={}
            for bl in blocks:
                for c,secs in anfp.parse(bl).items():
                    if c in D: D[c].update(secs)
                    else: D[c]=secs
            CACHE[k]=D
        C=CACHE[k]; spec=rest.strip()
    else: C=source(vol,work)
    if C is None: return None,['no source']
    paras=[]; probs=[]
    for (a,va),(b,vb) in parse(spec):
        for c in range(a,b+1):
            if c not in C: probs.append(f'missing chapter {c}'); continue
            vs=sorted(C[c]); lo=va if c==a else 1; hi=(vb if vb else max(vs)) if c==b else max(vs)
            got=[v for v in vs if lo<=v<=hi]
            for v in range(lo,hi+1):
                if v not in C[c]: probs.append(f'missing {c}:{v}')
            if c==b and vb and vb>max(vs): probs.append(f'end {c}:{vb} beyond {max(vs)}')
            if not got: continue
            p=' '.join(f'[{c}:{v}] '+tidy(C[c][v]) if (v!=lo or True) else tidy(C[c][v]) for v in got)
            import fixes; paras.append(fixes.apply(p))
    return paras,probs
if __name__=='__main__':
    only=sys.argv[1] if len(sys.argv)>1 else None
    R={}
    for key,(vol,work,spec) in WANT.items():
        if only and work!=only: continue
        paras,probs=excerpt(vol,work,spec)
        R[key]=dict(p=paras,probs=probs)
        bad=sorted(set(w for p in (paras or []) for w in re.findall(r"[A-Za-z’'\-]+",p) if not inv(w)))
        print('##',key,'|',probs,'| NONVOC:',bad[:25])
    json.dump(R,open('extract_'+(only or 'all')+'.json','w'),ensure_ascii=False,indent=1)
