import json,re,subprocess,sys,os
from PIL import Image,ImageOps
name,pdf,psm=sys.argv[1],sys.argv[2],sys.argv[3]
pages=[int(x) for x in sys.argv[4].split(',')]
os.makedirs('ocr_'+name,exist_ok=True)
for p in pages:
    out=f'ocr_{name}/{p:03d}'
    if os.path.exists(out+'.tsv'): continue
    tmp=f'/tmp/pg_{name}'
    subprocess.run(['pdftoppm','-f',str(p),'-l',str(p),'-r','300','-gray','-png','-singlefile',pdf,tmp])
    im=Image.open(tmp+'.png').convert('L'); im=ImageOps.autocontrast(im,cutoff=2).point(lambda v:255 if v>150 else 0)
    # remember padding so coordinates can be shifted back
    if psm=='cols':
        W,H=im.size; px=im.load()
        best=None
        for x in range(int(W*0.3),int(W*0.7)):
            ink=sum(1 for y in range(int(H*0.12),int(H*0.85),3) if px[x,y]==0)
            if best is None or ink>best[0]: best=(ink,x)
        g=best[1]
        for k,(a,b) in enumerate([(0,g-4),(g+5,W)]):
            ImageOps.expand(im.crop((a,0,b,H)),border=100,fill=255).save(tmp+'b.png')
            subprocess.run(['tesseract',tmp+'b.png',out+'_'+'LR'[k],'-l','eng','--psm','6','tsv','txt'],capture_output=True)
        open(out+'.tsv','w').write('')
    else:
        ImageOps.expand(im,border=100,fill=255).save(tmp+'b.png')
        subprocess.run(['tesseract',tmp+'b.png',out,'-l','eng','--psm',psm,'tsv','txt'],capture_output=True)
print('done',name,flush=True)
