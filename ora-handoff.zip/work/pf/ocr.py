import json,re,subprocess,sys,os
name,pdf=sys.argv[1],sys.argv[2]
pages=json.load(open(name+'_pages.json'))
os.makedirs('ocr_'+name,exist_ok=True)
for i,p in enumerate(pages):
    g=len(re.findall('[Ͱ-Ͽἀ-῿]',p)); e=len(re.findall('[a-z]',p))
    if e<300 or g>e*0.05: continue
    if name=='l2' and not (324<=i+1<=390): continue
    out=f'ocr_{name}/{i+1:03d}'
    if os.path.exists(out+'.tsv'): continue
    subprocess.run(['pdftoppm','-f',str(i+1),'-l',str(i+1),'-r','300','-gray','-png','-singlefile',pdf,'/tmp/pg_'+name])
    subprocess.run(['tesseract','/tmp/pg_'+name+'.png',out,'-l','eng','--psm','4','tsv'],capture_output=True)
print('done',name)
