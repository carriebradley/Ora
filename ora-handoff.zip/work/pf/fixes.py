# OCR corrections, applied to finished excerpt text (whole-word replacements)
FIX = {
 'Ser,':'See,', 'Ann':'And', 'Breturen':'Brethren', 'Bur':'But', 'Bur,':'But,', 'Forasmucn':'Forasmuch', 'Forasmucu':'Forasmuch',
 'Fry from':'Fly from', 'Hat,':'Hail,', 'Havinc':'Having', 'I GreET':'I greet', 'I peseecu':'I beseech', 'I po':'I do',
 'I reJoice':'I rejoice', 'I wave':'I have', 'I Give':'I give', 'I Have':'I have', 'I No':'I no', 'Knowine':'Knowing', 'Knowrne':'Knowing',
 'Seeinc':'Seeing', 'Seeme':'Seeing', 'Serine':'Seeing', 'Seemnc':'Seeing', 'Sreine':'Seeing', 'Sranp':'Stand', 'THererore':'Therefore',
 'Tins':'This', 'Trrus':'Thus', 'Tuererore':'Therefore', 'Tuese':'These', 'Waar':'What', 'Wetcomine':'Welcoming', 'Wieretrore':'Wherefore',
 '“Resgorce':'“Rejoice', 'Ler':'Let', 'Tue':'The', 'Anp':'And', 'Axp':'And', 'Tanine':'Taking', 'THese':'These', 'Sucu':'Such', 'Ixy':'In',
 'Bressep':'Blessed', 'TuHou':'Thou', 'Senn':'Send', 'Wo then':'Who then',
}
import re
def apply(s):
    # stray verse numbers left in the running text (OCR missed the verse break): drop them
    s=re.sub(r'(?<=[.;:!?,”’)\]"\']) (?:\d{1,2}|t|S|Ih|l\d|\+|\*|§|«)[.,]?\s*(?=[“‘"A-Z(])',' ',s)
    s=re.sub(r' 2\.“',' “',s)
    s=re.sub(r'(\[\d+:\d+\]) (?:lL\.|l\.|1\.|«\|\.|«|\|\.)\s+',r'\1 ',s)
    for a,b in FIX.items():
        s=re.sub(r'(?<![\w’])'+re.escape(a)+r'(?![\w’])',b,s)
    return apply2(s)

# Corrections found by reading every excerpt against the sense of Lake's text (substring replacements)
FIX2 = [
('cither seen','either seen'),('afso','also'),('ina mystery','in a mystery'),('Por what else','For what else'),('benelits','benefits'),
('Let us” fix','Let us fix'),('to hin.','to him.'),('from Ged','from God'),('Creator ot the','Creator of the'),('eee Eee ',''),('leave it- to','leave it to'),
('in citics','in cities'),('varicty','variety'),('dor practise','nor practise'),('sutter all','suffer all'),('forcign','foreign'),('otf\\pring','offspring'),
('is east vin the flesh.”','is cast “in the flesh,”'),('stafter the flesh','“after the flesh'),('They Jove','They love'),('butfeted','buffeted'),('batteted','buffeted'),
('*§ They are abused','“They are abused'),('gratifving','gratifying'),('ainong','among'),('in’ the body','in the body'),('as ina prison','as in a prison'),
('humble-iminded','humble-minded'),('Grant us! to hope','Grant us to hope'),('Let US unfold','Let us unfold'),('from him! come','from him come'),('hands.)','hands.'),
('Lam not yet','I am not yet'),('prepared? by','prepared by'),('you live? in','you live in'),('if lin a short','if I in a short'),("that all ' things",'that all things'),
('within § the','within the'),('give thanks! and','give thanks and'),
('they who corrupt. ilies shall inheri } ki “d f God families shall not inherit the kingdom o God','“they who corrupt families shall not inherit the kingdom of God.”'),
('crucified 2?','crucified?'),('‘hear his silence','hear his silence'),('Bat why','But why'),('devoted! to','devoted to'),('eternal lite','eternal life'),
('“Where is) the wise? Where is the disputer δ᾿’ Where','“Where is the wise? Where is the disputer?” Where'),('Jesus. Christ','Jesus Christ'),('his soul?! for','his soul for'),
('pray of: his','pray of his'),('remember >a good','remember a good'),('and) whose','and whose'),('and in’ whose','and in whose'),('nailed to-the','nailed to the'),
('to a tree! in','to a tree in'),('in the The flesh','in the flesh'),('beloved} knowing','beloved, knowing'),('thatbe','that be'),('unhin-dered','unhindered'),
('« God-pleasers','“God-pleasers'),('a chorus! of','a chorus of'),('visible.? Christianity','visible. Christianity'),('kindness’?! to me','kindness” to me'),('toany','to any'),
('instruments.?','instruments.'),('I ain even','I am even'),('soldiers!)','soldiers)'),('perversely.” 1)','perversely.”'),('Jesus; & for','Jesus; for'),('that To may','that I may'),
('without. disorder','without disorder'),('arguments let','arguments, let'),('hold! Eucharist','hold Eucharist'),('child, which, thou','child, which thou'),('Was scattered','was scattered'),
('taber- nacle','tabernacle'),('Maran atha,! Amen','Maran atha, Amen'),('confessing break your','confessing your'),('the reathen','the heathen'),('a time f pestilence','a time of pestilence'),
('counsel of facies','counsel of oracles'),('they ht rescue','they might rescue'),('con-~ fess','confess'),('in them there. may','in them there may'),('[If we endure','If we endure'),
('as [ was','as I was'),('Jesus Christ, ——!','Jesus Christ,—'),('It then they','If then they'),('the dead.!','the dead.'),('lost.? For','lost. For'),('sicknesses”” of all','sicknesses” of all'),
('It you love','If you love'),('serpent”’','serpent”'),('things ‘and pure','things and “pure'),('harbour.!| Be','harbour. Be'),('prize? is','prize is'),('lite, of','life, of'),
('—l and my','—I and my'),('as“an','as “an'),('Free from evil arts','Flee from evil arts'),('back-pay! due','back-pay due'),('resurrection.? ','resurrection. '),('Neapolis! as','Neapolis, as'),
('‘possessing','possessing'),('that you? may','that you may'),('in) order that Literally ‘‘spring.” your','in order that your'),('doctrines! of','doctrines of'),('were ¢ called’?','were “called”'),
('undertanding','understanding'),('creating us. afresh','creating us afresh'),('“See,’ saith','“See,” saith'),('them”’ (that','them” (that'),('thine eye” ’’ all','thine eye” all'),
('righteous judgment.””','righteous judgment.”'),('evil conscience, This','evil conscience. This'),('“te whom','“to whom'),('ve be not','ye be not'),('chastity,and','chastity, and'),
('anti-Christ”’;','anti-Christ”;'),('Satan.! [','Satan. ['),('flesh, is weak','flesh is weak'),('Bora you','Both you'),('IT am','I am'),('{i.e. Valens]','[i.e. Valens]'),
('For in) doing','For in doing'),('invain','in vain'),('fire..','fire.'),('devil} is','devil is'),('Jesus Christ? and','Jesus Christ, and'),('incorruptible) by Cross which','incorruptible) by which'),
('members. ‘The head','members. The head'),('in” their','in their'),('to whom! be','to whom be'),('fear God. & Let','fear God. Let'),('—* Come, Children, hearken to me, ] will','—“Come, Children, hearken to me, I will'),
('Who is’ the man','Who is the man'),('near io bim','near to him'),('has made. the','has made the'),('from hin?','from him?'),('Writing! says','Writing says'),('“Behold) the','“Behold the'),
('careless © in','careless “in'),('in hin; let us he subject','in him; let us be subject'),('conscience Land cry','conscience and cry'),('acceptable tu him','acceptable to him'),
('“T came','“I came'),('him! except','him, except'),('Father””’;','Father”;'),('from me.”.','from me.”'),('notsaveus','not save us'),('iniquity.”!','iniquity.”'),
('repent7rhe forthwith','repent forthwith'),('men~, pleasers','men-pleasers'),('car hath not','ear hath not'),('says:— Miserable','says:—“Miserable'),('Lam reading','I am reading'),
('reader! among','reader among'),('should) pay','should pay'),('punishes? a','punishes a'),('to to us','to us'),('ever.. Amen. The Second Epistle of Clement to the Corinthians.','ever. Amen.'),
('isthe','is the'),('rightegus','righteous'),('great Joy','great joy'),('some! of the heavens','some of the heavens'),('us;! [','us; ['),('Chureh','Church'),('is: blasphemed','is blasphemed'),
('at’ their','at their'),('if ve love','if ye love'),('extra- ordinary','extraordinary'),('If ve did','If ye did'),('and = was','and was'),('in’ the sight','in the sight'),
('= &. Thon hast','Thou hast'),('and [ kept','and I kept'),('[T will','I will'),(', ve who',', ye who'),('me,and','me, and'),('which IT will','which I will'),('with rai what','with what'),
('ungodli-ness','ungodliness'),('worship-ping','worshipping'),('Bur thanks','But thanks'),
]
OVERRIDE = {
 # Lake, II Clem. 12:1 (p. 147); the OCR of this page failed, transcribed from the page image
 ('2clem',12,1): 'Let us then wait for the kingdom of God, from hour to hour, in love and righteousness, seeing that we know not the day of the appearing of God.',
}
def apply2(s):
    for a,b in FIX2: s=s.replace(a,b)
    return s
