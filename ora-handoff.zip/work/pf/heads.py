import re,json
from tsvp import page_lines
def rom(s):
    t=''
    for ch in s:
        if ch=='L': t+='l'; continue
        if ch in 'IVXC': t+=ch.lower(); continue
        t+={'u':'ii','n':'ii','m':'iii','1':'i','l':'i','t':'i','r':'i','|':'i','!':'i','y':'v','w':'iv'}.get(ch.lower() if ch.isupper() else ch, ch.lower())
    vals={'i':1,'v':5,'x':10,'l':50,'c':100}
    if not t or any(ch not in vals for ch in t): return None
    n=0
    for k,ch in enumerate(t):
        v=vals[ch]; nxt=vals[t[k+1]] if k+1<len(t) else 0
        n+= -v if v<nxt else v
    return n
def head_range(tsv,pdfhead=''):
    ls=page_lines(tsv)
    cands=[]
    if ls: cands.append(' '.join(w['x'] for w in ls[0]['ws']))
    cands.append(pdfhead)
    res=[]
    for h in cands:
        m=re.search(r',\s*([^\s.]+)\.?\s*(\d+)\s*[-—~–]+\s*(?:([^\s.]+)\.\s*)?(\d+)',h)
        if m:
            a=rom(m.group(1)); b=rom(m.group(3)) if m.group(3) else a
            res.append(((a,int(m.group(2))),(b,int(m.group(4)))))
    return res
if __name__=='__main__':
    import sys
    P=json.load(open('l1_pages.json'))
    for p in sys.argv[1:]:
        p=int(p); print(p,head_range(f'ocr_l1/{p:03d}.tsv',P[p-1].strip().split('\n')[0]))
