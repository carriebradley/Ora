import subprocess,sys,os,glob
from PIL import Image,ImageOps
name,pdf=sys.argv[1],sys.argv[2]; pages=[int(x) for x in sys.argv[3].split(',')]
os.makedirs('ocr_'+name,exist_ok=True)
for p in pages:
    for f in glob.glob('/tmp/sm-*'): os.remove(f)
    subprocess.run(['pdfimages','-f',str(p),'-l',str(p),'-png',pdf,'/tmp/sm'])
    fs=sorted(glob.glob('/tmp/sm-*.png'))
    big=max(fs,key=lambda f:Image.open(f).size[0]*Image.open(f).size[1]*(1 if Image.open(f).mode in ('1','L') else 0.5))
    im=Image.open(big).convert('L')
    h=im.histogram()
    if sum(h[:128])>sum(h[128:]): im=ImageOps.invert(im)
    W,H=im.size; s=0.8
    im=im.resize((int(W*s),int(H*s)),Image.LANCZOS)
    ImageOps.expand(im,border=100,fill=255).save('/tmp/smb.png')
    subprocess.run(['tesseract','/tmp/smb.png',f'ocr_{name}/{p:03d}','-l','eng','--psm','6','tsv','txt'],capture_output=True)
print('done',name)
